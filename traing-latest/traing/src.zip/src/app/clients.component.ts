import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'clients',
    templateUrl: 'clients.component.html'
})

export class ClientsComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}