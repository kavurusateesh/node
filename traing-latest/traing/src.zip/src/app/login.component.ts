import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'login',
    template:"I am in login page"
})

export class LoginComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}