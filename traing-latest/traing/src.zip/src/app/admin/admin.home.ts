import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'admin-home',
    template:"I am in admin home page"
})

export class AdminHomeComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}