
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';

import { AdminService } from './admin.service';
import { User } from './admin';



@Component({
    selector: 'admin-register',
    templateUrl:'./admin.register.component.html'
})

export class AdminRegisterComponent  {
    
    admin:User
    //user:User;
    constructor(private ad:AdminService,private router:Router) {
     this.admin = new User();
     }

   
    register()
    {
     this.ad.registerAdmin(this.admin).subscribe(
         (data)=>{ //console.log(data);
         if(data != 'fail')
    {
       alert("data is successfully Inserted");
       this.router.navigate(['/admin/login']); 
    }
    else
    {
        alert("Kindly check your field entries");
    }
})  
    }


}