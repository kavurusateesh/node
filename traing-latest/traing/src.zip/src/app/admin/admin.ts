
/*
export class Admins{
    fname:string;
    lname:string;
    username:string;
    password:string;
    
}  */


export class User{
    name:string;
    username:string;
    password:string;
    relation:string;
    gender:string;
    language:string;
}