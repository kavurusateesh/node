



import { AdminService } from './admin.service';
import { User } from './admin';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Route, Router } from '@angular/router';


@Component({
    selector: 'editUser',
    templateUrl: 'adminuseredit.component.html'
})

export class EditUserComponent implements OnInit {
    admin:User;
    constructor(private us:AdminService,private route:ActivatedRoute,router:Router) 
    {
        this.admin = new User();

        var userId = this.route.snapshot.params['userId'];
        alert(userId);
        
        this.us.userEditPage(userId).subscribe((data)=>{
            this.admin = <User>data;
        })

     }

    ngOnInit() { }
}