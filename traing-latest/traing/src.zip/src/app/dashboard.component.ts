import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'dashboard',
    template:"in dashboard page"
})

export class DashboardComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}