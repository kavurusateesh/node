import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'home',
    template:"I am in Home component"
})

export class HomeComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}