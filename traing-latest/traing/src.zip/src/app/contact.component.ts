import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'contact',
    template:"I am in Contact page"
})

export class ContactComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}