module.exports={
    local:{
        db:"mongodb://localhost/trainDb"
    },
    prod:{
        db:"mongodb://10.112.21.23/trainDb"
    }
}