module.exports={
    local:{db:"mongodb://localhost/trainDb"},
    prod:{db:"mongodb://10.20.25.23/trainDB"}
}


