var express = require("express");
var path = require("path");
var bodyParser = require("body-parser");
var mongojs = require("mongojs");

//var mongoos = require("mongoose");

var app = express();

var router = express.Router();

//var db = mongoos.connect('mongodb://localhost/trainDb');

var db = mongojs('mongodb://localhost/trainDb');

app.use(express.static(path.join(__dirname,"../../dist/project1/")));
app.use(bodyParser.urlencoded({extended:false}));
app.use(bodyParser.json());

//console.log(__dirname);

//  --  methods -- //

router.get("/api/listusers",function(req,res)
{
    db.users.find({},function(err,docs)
    {
        if(err)
        {
            res.failure(err);
        }
        else
        {
        res.json(docs);
        }
    });
});

router.get("/api/listusersaddress", function(req,res){

    
    db.useraddress.find({}, function(err,docs){
        res.json(docs);
    });
});
router.post("/api/registerUser",function(req,res)
{
var lenght = Object.keys(req.body).length;
  
//console.log(lenght);
   
    if(lenght > 1){
        
db.users.insert({firstname:req.body.fname,lastname:req.body.lname},function(err, docs){
    res.json(docs);

});
    }
    else
    {
       res.json("fail");
    }
   
});
router.get("/api/editUser/:id",function(req,res){
   // console.log(req.params.id);

    db.users.findOne({_id:mongojs.ObjectId(req.params.id)}, function(err,docs)
    {
        res.json(docs);
    });
})

router.put("/api/updateUser", function(req,res){

   // console.log(req.body._id);

    db.users.findAndModify({
        query:{_id:mongojs.ObjectId(req.body._id)},
        update:{$set:{firstname:req.body.firstname,lastname:req.body.lastname}},
        new:true
    },
    function(err,docs){
        res.json(docs);
    });
});


router.delete("/api/deleteUser/:id",function(req,res){
    db.users.remove({_id:mongojs.ObjectId(req.params.id)},function(err,docs)
    {
        res.json(docs);
    });
})

router.post("/api/loginUser",function(req,res){

    var lenght = Object.keys(req.body).length;
   // db.users.insert({firstname:req.body.fname,lastname:req.body.lname},function(err, docs){
      //  db.users.findOne({_id:mongojs.ObjectId(req.params.id)}, function(err,docs)
        db.Users.findOne({username:req.body.username,password:req.body.password}).exec(function(err,docs)
        {
        res.json(docs);
        

})
});

console.log("connet succ");
app.use(router);
app.listen(8085);






