var express = require ("express");
var app  = express();
var router = express.Router();
var bodyParser = require("body-parser");
var mongosjs = require("mongojs");
var path = require("path");

var db = mongosjs("mongodb://localhost:trainDB",[]);
app.use(express.static(path.join(__dirname,"../../dist/project1")));
app.use(bodyParser.json());

console.log(__dirname);
app.listen(8085);



