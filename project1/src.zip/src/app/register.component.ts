
import { UserService } from './user.service';
import { Component, OnInit } from '@angular/core';
import { User } from './user';
import { Router } from '@angular/router';

@Component({
    selector: 'register',
    templateUrl: 'register-form.component.html'
})

export class RegisterComponent implements OnInit {
    user:User;
    constructor(private us:UserService, private router : Router) { 

        this.user = new User();
       
    }

    register()
        {
         this.us.registerUser(this.user).subscribe(
             (data)=>{ //console.log(data);
             if(data != 'fail')
        {
           alert("data is successfully Inserted");
           this.router.navigate(['/UserList']); 
        }
        else
        {
            alert("Kindly check your field entries");
        }
    })  
        }

    ngOnInit() { }
}