import { User } from './user';
import { Component, OnInit } from '@angular/core';
import { UserService } from './user.service';

 

@Component({
    selector: 'userList',
    templateUrl: 'userList.component.html'
})

export class UserListComponent implements OnInit {
    users:User;
    constructor(private us:UserService) {



        this.us.listUsers().subscribe((data)=>{if(data)
            {
             //console.log(data);
             this.users =<User>data 
            }
        });
        
     }

     userDelete(userId)
     {
         
       this.us.deleteUser(userId).subscribe((data)=>{

           if(data)
           {
               this.us.listUsers().subscribe((data)=>{
                   if(data){ this.users = <User>data; }
               })
           }
       })
     }

    ngOnInit() { }
}