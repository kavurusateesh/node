import { UserAddressListComponent } from './user.address.list.componet';

import { FormsModule } from '@angular/forms';
import { RouterModule, RoutesRecognized } from '@angular/router';

import { routes } from './app.routes';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { MenuComponent } from './menu';

import { AboutComponent } from './about.component';
import { RegisterComponent } from './register.component';
import { HttpClientModule } from '@angular/common/http';
import { UserService } from './user.service';
import { UserListComponent } from './userList.component';
import { HomeComponent } from './home.component';
import { EditUserComponent } from './editusercomponent';
import { LoginComponent } from './login.component';


@NgModule({
  declarations: [
    AppComponent,MenuComponent,AboutComponent,RegisterComponent,UserListComponent,HomeComponent,EditUserComponent,
    UserAddressListComponent,LoginComponent 
  ],
  imports: [
    BrowserModule,RouterModule.forRoot(routes), FormsModule,HttpClientModule
  ],
  providers: [UserService],
  bootstrap: [AppComponent]
})
export class AppModule { }

