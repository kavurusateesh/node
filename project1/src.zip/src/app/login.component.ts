import { Router } from '@angular/router';
import { UserService } from './user.service';
import { User } from './user';
import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'Login',
    templateUrl: 'login.component.html'
})

export class LoginComponent implements OnInit {
    user:User;
    constructor(private us:UserService, private router:Router) {

        this.user = new User();
     }

    ngOnInit() { }

login()
{
    this.us.loginUser(this.user).subscribe((data)=>{

        if(data){ alert("Successfully Login");
    this.router.navigate(['/UserList']);
    }
    })
}


}
