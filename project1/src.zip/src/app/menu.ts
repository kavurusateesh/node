import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'menu',
    templateUrl: 'menu.html'
})

export class MenuComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}