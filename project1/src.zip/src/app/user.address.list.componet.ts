import { Useraddress } from './useraddress';
import { UserService } from './user.service';
import { Component, OnInit } from '@angular/core';
@Component({
    selector: 'useraddresslist',
    templateUrl: 'userAddressList.component.html'
})



export class UserAddressListComponent implements OnInit {
    

    useraddress:Useraddress
    constructor(private us:UserService) {
        
        this.us.listUserAddress().subscribe((data)=>{
           // console.log(data);
            if(data)
            {
                this.useraddress= <Useraddress>data
            }
        })
      
       
    }

    

    ngOnInit() { }
}



