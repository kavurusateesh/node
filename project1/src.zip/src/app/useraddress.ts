export class Useraddress
    {
        username:string;
        address:string;
        village:string;
        pincode:number;

    }