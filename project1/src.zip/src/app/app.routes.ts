import { UserAddressListComponent } from './user.address.list.componet';
import { RegisterComponent } from './register.component';
import { AboutComponent } from './about.component';
import { HomeComponent } from "./home.component";
import { UserListComponent } from './userList.component';
import { EditUserComponent } from './editusercomponent';
import { LoginComponent } from './login.component';

export const routes = [
    {path:"Home", component:HomeComponent},
    {path:"About",component:AboutComponent},
    {path:"UserList", component:UserListComponent},
    {path:"Registerform", component:RegisterComponent},
    {path:"editUrl/:userId", component:EditUserComponent},
    {path:"UserAddressList", component:UserAddressListComponent},
    {path:"Login",component:LoginComponent},
    {path:"", component:HomeComponent}
]