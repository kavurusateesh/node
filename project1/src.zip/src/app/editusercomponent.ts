import { Component, OnInit } from '@angular/core';
import { User } from './user';
import { UserService } from './user.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
    selector: 'editUser',
    templateUrl: 'edituser.component.html'
})

export class EditUserComponent implements OnInit {
    user:User;
    constructor(private us:UserService,private route:ActivatedRoute,private router:Router) {
        this.user = new User();
        var userId = this.route.snapshot.params['userId'];
        alert(userId);

        this.us.userEdit(userId).subscribe((data)=>{if(data){
            this.user = <User>data
        }})
     }
     update()
     {
         this.us.updateUser(this.user).subscribe((data)=>{
             if(data)
             {
                alert("data is Updated successfully");
           this.router.navigate(['/UserList']); 
             }
         })
     }
     cancel()
     {
         this.router.navigate(['/UserList']);
     }

    ngOnInit() { }
}