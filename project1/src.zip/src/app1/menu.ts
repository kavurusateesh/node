import {Component} from "@angular/core";
@Component({
    selector:"menu",
    templateUrl:"menu.html"
})
export class MenuComponent{
    
}