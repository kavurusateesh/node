import { Component } from "@angular/core";
@Component({
    selector:"About",
    templateUrl:"./about.component.html"
})
export class AboutComponent{

}
