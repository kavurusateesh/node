export class User{
    fname:string;
    lname:string;
}