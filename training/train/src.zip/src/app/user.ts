export class User{
    name:string;
    username:string;
    password:string;
    relation:string;
    gender:string;
    language:string;
}