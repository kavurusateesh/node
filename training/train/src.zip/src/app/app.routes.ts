import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { DashboardComponent } from "./dashboard/dashboard.component";

export const routes = [
    {path:"dashbord", component:DashboardComponent},
    {path:"registerpage", component:RegisterComponent},
    {path:"loginpage",  component:LoginComponent}
    
]