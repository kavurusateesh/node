var WebSocketServer = require("ws").Server;
var wss = new WebSocketServer({port:3500});

wss.on("connection", function(ws){
    //console.log("satish");

    ws.on("message",function(message){
        //console.log(message);
        if(message === 'exit')
        {
            ws.close();
        }
        else
        {
            //console.log(clients);
            wss.clients.forEach(function(client)
            {
               //console.log(message);

                client.send(message);
            });
        }
    });
    ws.send("welcome to cyber connetion");
});
console.log("web socket is runing");